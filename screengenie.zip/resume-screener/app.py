import os
import io
import sqlite3
import json
import mimetypes
from datetime import datetime

from flask import Flask, render_template, request, redirect, url_for, g, flash, send_file, abort

from parsing import (
    extract_text_from_file,
    extract_resumes_from_zip,
    top_keywords,
    analyze_resume,
    grade_for_score,
    status_for_score,
)

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(BASE_DIR, "screengenie.db")

app = Flask(__name__)
app.secret_key = "screen-genie-internal-dev-key"
app.config["MAX_CONTENT_LENGTH"] = 60 * 1024 * 1024  # 60 MB


def get_db():
    if "db" not in g:
        g.db = sqlite3.connect(DB_PATH)
        g.db.row_factory = sqlite3.Row
    return g.db


@app.teardown_appcontext
def close_db(exception=None):
    db = g.pop("db", None)
    if db is not None:
        db.close()


def init_db():
    db = sqlite3.connect(DB_PATH)
    db.executescript(
        """
        CREATE TABLE IF NOT EXISTS scans (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            jd_filename TEXT NOT NULL,
            jd_role TEXT,
            keywords TEXT,
            resume_count INTEGER NOT NULL,
            avg_score REAL NOT NULL,
            created_at TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS candidates (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            scan_id INTEGER NOT NULL,
            filename TEXT NOT NULL,
            name TEXT,
            email TEXT,
            phone TEXT,
            score INTEGER NOT NULL,
            grade TEXT NOT NULL,
            status TEXT NOT NULL,
            section_scores TEXT,
            matched_keywords TEXT,
            missing_keywords TEXT,
            matched_skills TEXT,
            missing_skills TEXT,
            extra_skills TEXT,
            reasons TEXT,
            file_data BLOB,
            suggestions TEXT,
            passed_checks TEXT,
            warning_checks TEXT,
            issue_checks TEXT,
            semantic_score INTEGER,
            FOREIGN KEY (scan_id) REFERENCES scans (id)
        );
        """
    )
    db.commit()
    db.close()


def guess_role(jd_text, jd_filename):
    for line in jd_text.splitlines():
        line = line.strip()
        if line:
            return line[:80]
    return jd_filename


@app.route("/")
def index():
    return render_template("bulk_screener.html")


@app.route("/scan", methods=["POST"])
def scan():
    jd_file = request.files.get("jd_file")
    resume_mode = request.form.get("resume_mode", "files")

    if not jd_file or jd_file.filename == "":
        flash("Please upload a job description file.")
        return redirect(url_for("index"))

    jd_text = extract_text_from_file(jd_file.filename, jd_file.stream)
    if not jd_text.strip():
        flash("Could not read text from the job description file.")
        return redirect(url_for("index"))

    resume_docs = []  # list of (filename, text, raw_bytes)

    if resume_mode == "zip":
        zip_file = request.files.get("resume_zip")
        if not zip_file or zip_file.filename == "":
            flash("Please upload a ZIP file of resumes.")
            return redirect(url_for("index"))
        resume_docs = extract_resumes_from_zip(zip_file.stream)
    else:
        files = request.files.getlist("resume_files")
        files = [f for f in files if f and f.filename]
        if not files:
            flash("Please select one or more resume files.")
            return redirect(url_for("index"))
        for f in files:
            raw = f.read()
            text = extract_text_from_file(f.filename, io.BytesIO(raw))
            resume_docs.append((f.filename, text, raw))

    resume_docs = [(name, text, raw) for name, text, raw in resume_docs if text.strip()]
    if not resume_docs:
        flash("No readable resumes were found (check file formats: PDF, DOCX, TXT).")
        return redirect(url_for("index"))

    keywords = top_keywords(jd_text, n=15)
    jd_role = guess_role(jd_text, jd_file.filename)

    candidates = []
    for filename, text, raw in resume_docs:
        analysis = analyze_resume(jd_text, text, keywords)
        score = analysis["score"]
        candidates.append({
            "filename": filename,
            "name": analysis["contact"]["name"],
            "email": analysis["contact"]["email"],
            "phone": analysis["contact"]["phone"],
            "score": score,
            "grade": grade_for_score(score),
            "status": status_for_score(score),
            "section_scores": analysis["section_scores"],
            "matched_keywords": analysis["matched_keywords"],
            "missing_keywords": analysis["missing_keywords"],
            "matched_skills": analysis["matched_skills"],
            "missing_skills": analysis["missing_skills"],
            "extra_skills": analysis["extra_skills"],
            "reasons": analysis["reasons"],
            "suggestions": analysis.get("suggestions", []),
            "passed_checks": analysis.get("passed_checks", []),
            "warning_checks": analysis.get("warning_checks", []),
            "issue_checks": analysis.get("issue_checks", []),
            "semantic_score": analysis.get("semantic_score", 0),
            "raw": raw,
        })

    candidates.sort(key=lambda c: c["score"], reverse=True)
    avg_score = round(sum(c["score"] for c in candidates) / len(candidates), 1)

    db = get_db()
    cur = db.execute(
        "INSERT INTO scans (jd_filename, jd_role, keywords, resume_count, avg_score, created_at) "
        "VALUES (?, ?, ?, ?, ?, ?)",
        (jd_file.filename, jd_role, json.dumps(keywords), len(candidates), avg_score,
         datetime.utcnow().isoformat()),
    )
    scan_id = cur.lastrowid

    for c in candidates:
        db.execute(
            "INSERT INTO candidates (scan_id, filename, name, email, phone, score, grade, status, "
            "section_scores, matched_keywords, missing_keywords, matched_skills, missing_skills, "
            "extra_skills, reasons, file_data, suggestions, passed_checks, warning_checks, "
            "issue_checks, semantic_score) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
            (scan_id, c["filename"], c["name"], c["email"], c["phone"], c["score"], c["grade"],
             c["status"], json.dumps(c["section_scores"]), json.dumps(c["matched_keywords"]),
             json.dumps(c["missing_keywords"]), json.dumps(c["matched_skills"]),
             json.dumps(c["missing_skills"]), json.dumps(c["extra_skills"]),
             json.dumps(c["reasons"]), c["raw"],
             json.dumps(c["suggestions"]), json.dumps(c["passed_checks"]),
             json.dumps(c["warning_checks"]), json.dumps(c["issue_checks"]),
             c["semantic_score"]),
        )
    db.commit()

    return redirect(url_for("results", scan_id=scan_id))


@app.route("/results/<int:scan_id>")
def results(scan_id):
    db = get_db()
    scan_row = db.execute("SELECT * FROM scans WHERE id = ?", (scan_id,)).fetchone()
    if not scan_row:
        flash("Scan not found.")
        return redirect(url_for("index"))

    candidate_rows = db.execute(
        "SELECT id, scan_id, filename, name, email, phone, score, grade, status, "
        "section_scores, matched_skills, missing_skills FROM candidates "
        "WHERE scan_id = ? ORDER BY score DESC",
        (scan_id,),
    ).fetchall()

    candidates = []
    for row in candidate_rows:
        c = dict(row)
        c["section_scores"] = json.loads(c["section_scores"])
        c["matched_skills"] = json.loads(c["matched_skills"])
        c["missing_skills"] = json.loads(c["missing_skills"])
        candidates.append(c)

    keywords = json.loads(scan_row["keywords"])

    return render_template(
        "results.html", scan=scan_row, candidates=candidates, keywords=keywords
    )


@app.route("/candidate/<int:candidate_id>")
def candidate_detail(candidate_id):
    db = get_db()
    row = db.execute(
        "SELECT id, scan_id, filename, name, email, phone, score, grade, status, "
        "section_scores, matched_keywords, missing_keywords, matched_skills, missing_skills, "
        "extra_skills, reasons, suggestions, passed_checks, warning_checks, issue_checks, "
        "semantic_score, (file_data IS NOT NULL) AS has_file FROM candidates WHERE id = ?",
        (candidate_id,),
    ).fetchone()
    if not row:
        flash("Candidate not found.")
        return redirect(url_for("index"))

    candidate = dict(row)
    candidate["section_scores"] = json.loads(candidate["section_scores"])
    candidate["matched_keywords"] = json.loads(candidate["matched_keywords"])
    candidate["missing_keywords"] = json.loads(candidate["missing_keywords"])
    candidate["matched_skills"] = json.loads(candidate["matched_skills"])
    candidate["missing_skills"] = json.loads(candidate["missing_skills"])
    candidate["extra_skills"] = json.loads(candidate["extra_skills"])
    candidate["reasons"] = json.loads(candidate["reasons"])
    candidate["suggestions"] = json.loads(candidate["suggestions"]) if candidate["suggestions"] else []
    candidate["passed_checks"] = json.loads(candidate["passed_checks"]) if candidate["passed_checks"] else []
    candidate["warning_checks"] = json.loads(candidate["warning_checks"]) if candidate["warning_checks"] else []
    candidate["issue_checks"] = json.loads(candidate["issue_checks"]) if candidate["issue_checks"] else []

    scan_row = db.execute("SELECT * FROM scans WHERE id = ?", (candidate["scan_id"],)).fetchone()

    return render_template("candidate.html", candidate=candidate, scan=scan_row)


def _send_resume(candidate_id, as_attachment):
    db = get_db()
    row = db.execute(
        "SELECT filename, file_data FROM candidates WHERE id = ?", (candidate_id,)
    ).fetchone()
    if not row or row["file_data"] is None:
        abort(404)
    mimetype, _ = mimetypes.guess_type(row["filename"])
    return send_file(
        io.BytesIO(row["file_data"]),
        mimetype=mimetype or "application/octet-stream",
        as_attachment=as_attachment,
        download_name=row["filename"],
    )


@app.route("/candidate/<int:candidate_id>/view")
def candidate_view_file(candidate_id):
    return _send_resume(candidate_id, as_attachment=False)


@app.route("/candidate/<int:candidate_id>/download")
def candidate_download_file(candidate_id):
    return _send_resume(candidate_id, as_attachment=True)


@app.route("/history")
def history():
    db = get_db()
    scans = db.execute("SELECT * FROM scans ORDER BY created_at DESC").fetchall()
    return render_template("history.html", scans=scans)


@app.route("/history/<int:scan_id>/delete", methods=["POST"])
def delete_scan(scan_id):
    db = get_db()
    db.execute("DELETE FROM candidates WHERE scan_id = ?", (scan_id,))
    db.execute("DELETE FROM scans WHERE id = ?", (scan_id,))
    db.commit()
    flash("Scan deleted.")
    return redirect(url_for("history"))


@app.route("/dashboard")
def dashboard():
    db = get_db()
    scans = db.execute("SELECT * FROM scans").fetchall()
    candidates = db.execute(
        "SELECT id, scan_id, filename, name, score, grade, status FROM candidates"
    ).fetchall()

    total_resumes = len(candidates)
    total_scans = len(scans)
    shortlisted = sum(1 for c in candidates if c["status"] == "Shortlist")
    avg_score = round(sum(c["score"] for c in candidates) / total_resumes, 1) if total_resumes else 0

    buckets = {"0-39": 0, "40-59": 0, "60-79": 0, "80-100": 0}
    for c in candidates:
        s = c["score"]
        if s < 40:
            buckets["0-39"] += 1
        elif s < 60:
            buckets["40-59"] += 1
        elif s < 80:
            buckets["60-79"] += 1
        else:
            buckets["80-100"] += 1

    grade_counts = {"A": 0, "B": 0, "C": 0, "D": 0}
    for c in candidates:
        grade_counts[c["grade"]] = grade_counts.get(c["grade"], 0) + 1

    top_candidates = db.execute(
        "SELECT id, scan_id, filename, name, score, grade, status FROM candidates "
        "ORDER BY score DESC LIMIT 8"
    ).fetchall()

    recent_scans = db.execute(
        "SELECT * FROM scans ORDER BY created_at DESC LIMIT 5"
    ).fetchall()

    return render_template(
        "dashboard.html",
        total_resumes=total_resumes,
        total_scans=total_scans,
        shortlisted=shortlisted,
        avg_score=avg_score,
        buckets=buckets,
        grade_counts=grade_counts,
        top_candidates=top_candidates,
        recent_scans=recent_scans,
    )


if __name__ == "__main__":
    init_db()
    app.run(host="0.0.0.0", port=5000, debug=True)
